-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 03 2018 г., 06:55
-- Версия сервера: 5.7.17-log
-- Версия PHP: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `spcart_bot`
--

-- --------------------------------------------------------

--
-- Структура таблицы `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` char(16) NOT NULL COMMENT 'логин в telegram',
  `product_count` int(11) NOT NULL COMMENT 'кол-во наименований',
  `amount` varchar(32) NOT NULL COMMENT 'Общая сумма',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `user_id` char(16) DEFAULT NULL COMMENT 'логин в telegram',
  `product_id` int(11) DEFAULT '1' COMMENT 'Номер товара в корзине',
  `price` varchar(256) NOT NULL DEFAULT '0' COMMENT 'цена',
  `quantity` varchar(256) NOT NULL COMMENT 'кол-во',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `products_temp`
--

CREATE TABLE `products_temp` (
  `id` int(11) NOT NULL,
  `user_id` char(16) DEFAULT NULL COMMENT 'логин в telegram',
  `price` varchar(256) NOT NULL DEFAULT '0' COMMENT 'цена',
  `quantity` varchar(256) NOT NULL DEFAULT '1' COMMENT 'кол-во',
  `action` char(1) NOT NULL DEFAULT 'c' COMMENT 'Текущие действие: c - create / u - update',
  `kb_mode` char(1) DEFAULT 'p' COMMENT 'Режим клавиатуры калк.: p - price / q - quantity',
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `flag_price_use` char(1) NOT NULL DEFAULT 'n',
  `flag_quantity_use` char(1) NOT NULL DEFAULT 'n'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user_id`),
  ADD KEY `amount` (`amount`),
  ADD KEY `product_count` (`product_count`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `price` (`price`),
  ADD KEY `quantity` (`quantity`),
  ADD KEY `user_pid` (`user_id`,`product_id`);

--
-- Индексы таблицы `products_temp`
--
ALTER TABLE `products_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `price` (`price`),
  ADD KEY `quantity` (`quantity`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT для таблицы `products_temp`
--
ALTER TABLE `products_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
